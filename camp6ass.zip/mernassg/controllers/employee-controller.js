const express = require('express');
// const {v4 : uuidv4} = require('uuid');
const {validationResult}=require('express-validator');
const HttpError = require('../model/http-errors');
const Employee=require('../model/employee');
const Department=require('../model/department');
const mongoose = require('mongoose');
// const employee = require('../model/employee');


//get employees by employeeid
const getEmployeeById = async (req,res,next)=>{
    console.log("GET Request in employeesid function");
    const employeeId = req.params.eid;


    let employee;
    try{
        employee = await Employee.findById(employeeId);
    }
    catch(err){
        const error = new HttpError;
        ('something went wrong, could not employee a place',500);
        return next(error);
    }

    if(!employee){
        
        throw new httpError('could not find a employee with given id',404)
    }
    //converting id to string: toObject({getters:true})
    res.json({employee:employee.toObject({getters:true})})
}




const getallEmployee = async (req, res, next) => {
    let employee;
    try {
        employee = await Employee.find(); // Fetch all employees
    } catch (err) {
        const error = new HttpError('Geting employees failed, please try again later.', 500);
        return next(error);
    }

    res.json({ employee: employee.map(employee => employee.toObject({ getters: true })) });
};


const createEmployee = async (req, res, next) => { 
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        console.log(errors);
        return next(new HttpError('Invalid inputs passed, please check your data', 422)); // Fix: return the error
    }

    const { fullname, email, position, dateOfBirth, dateOfJoining, salary, department } = req.body;
    
    // Create a new employee
    const createEmployee = new Employee({
        fullname: fullname,
        email: email,
        position: position,
        dateOfBirth: dateOfBirth,
        dateOfJoining: dateOfJoining,
        salary: salary,
        department: department
    });

    let dept;
    try {
        // Find the department by ID
        dept = await Department.findById(department);
    } catch (err) {
        const error = new HttpError('Finding department failed, please try again', 500);
        return next(error);
    }

    if (!dept) {
        const error = new HttpError('Could not find department with the provided ID, please try again', 404);
        return next(error);
    }

    // Save the employee
    try {
        const sess = await mongoose.startSession();
        sess.startTransaction();
        
        // Save the employee
        await createEmployee.save({ session: sess });
        
        // Add the employee to the department
        dept.employees.push(createEmployee._id);
        await dept.save({ session: sess });
        
        await sess.commitTransaction();
    } catch (err) {
        console.error("Error during employee creation:", err); // Log the detailed error
        const error = new HttpError('Creating employee failed, please try again', 500);
        return next(error);
    }
    

    res.status(201).json({ employee: createEmployee });
}




//update
const updateEmployee=async(req,res,next)=>{
    //iam gone update two fields
    const{fullname,position}=req.body;
    const employeeId = req.params.eid;
   
    //fetching the place by id
    let employee;
    try{
        employee=await Employee.findById(employeeId);

    }catch(err){
        const error=new HttpError('updating employee failed!',500);
        return next(error);

    }
    //update the title and description
    employee.fullname=fullname;
    employee.position=position;
    
    try{
        await employee.save();
    }catch(err){
        const error=new HttpError('some thing went wrong on update!',500);
        return next(error);
    }
    res.status(200).json({employee:employee.toObject({getters:true})})

}

//DELETE

const deleteEmployee = async (req, res, next) => {
    const employeeId = req.params.eid;

    let employee;
    try {
        // Find the employee and populate the department
        employee = await Employee.findById(employeeId).populate('department');
    } catch (err) {
        console.error("Error finding employee:", err); 
        const error = new HttpError('Something went wrong while deleting...', 500);
        return next(error);
    }

    if (!employee) {
        const error = new HttpError('Could not find the employee for this ID', 404);
        return next(error);
    }

    try {
        const sess = await mongoose.startSession();
        sess.startTransaction();

        // Delete the employee
        await employee.deleteOne({ session: sess });

        
        employee.department.employees.pull(employee._id);
        
        
        await employee.department.save({ session: sess });
        
        await sess.commitTransaction();
    } catch (err) {
        console.error("Error during employee deletion:", err); // Log the detailed error
        const error = new HttpError('Something went wrong while deleting...', 500);
        return next(error);
    }

    res.status(200).json({ message: 'Employee Deleted Successfully' });
};

exports.createEmployee=createEmployee;
exports.getEmployeeById=getEmployeeById;
exports.updateEmployee=updateEmployee;
exports.getallEmployee=getallEmployee;
exports.deleteEmployee=deleteEmployee;