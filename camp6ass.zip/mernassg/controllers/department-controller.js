const express = require('express');
// const {v4 : uuidv4} = require('uuid');
const {validationResult}=require('express-validator');
const HttpError = require('../model/http-errors');
const Department=require('../model/department');



const createDepartment = async (req,res,next)=>{
    const errors = validationResult(req);
    if(!errors.isEmpty()){
        console.log(errors);
        throw new HttpError('Invalid inputs... please check your data',422)
    }

    const {name} = req.body



    const createDepartment = new Department({
        name: name,
        employees:[]
        

    })
    try{
        await createDepartment.save();
    }catch(err){
        const error = new HttpError('Department creation failed!!..',500);
        return next(error);
    }
    res.status(201).json({department:createDepartment});

}


//getting all department
const getalldepartment = async (req, res, next) => {
    console.log("GET Request in departments");
    let department;
    try {
        department= await Department.find(); // Fetch all departments
    } catch (err) {
        const error = new HttpError('Geting departments failed, please try again later.', 500);
        return next(error);
    }

    res.json({ department: department.map(department => department.toObject({ getters: true })) });
};







exports.createDepartment=createDepartment;
exports.getalldepartment=getalldepartment;