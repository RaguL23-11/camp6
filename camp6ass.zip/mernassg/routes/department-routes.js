const express = require('express');

//create a router object to handle routes or path
const router = express.Router();
//import  placecontroller
const departmentControllers = require('../controllers/department-controller')

const {check}=require('express-validator');





router.post('/', [
    check('name').isLength({ min: 3 }), 
], departmentControllers.createDepartment);

router.get('/',departmentControllers.getalldepartment);







module.exports = router